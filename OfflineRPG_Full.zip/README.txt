OfflineRPG_Full - Godot offline demo project
------------------------------------------
Contains:
- Scenes: Menu, Summon, Inventory, MapUI, BossMapUI, HeroDetail
- scripts/global.gd: core systems (heroes, inventory, map, boss, summon, save/load)
- BGM included (res/res_bgm.ogg)
- export_presets.cfg included for Android export
- .github/workflows/build.yml for GitHub Actions sample

Usage:
- Unzip, open in Godot 3.5.3 (or 3.5.x) editor, ensure export templates are installed.
- For building APK: use Godot export or GitHub Actions workflow included.
